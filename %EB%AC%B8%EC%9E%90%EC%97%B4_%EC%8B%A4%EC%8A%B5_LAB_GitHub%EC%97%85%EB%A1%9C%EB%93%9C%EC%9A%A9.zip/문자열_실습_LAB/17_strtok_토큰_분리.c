#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "Man is immortal, because he has a soul";
    char seps[] = " ,\t\n";
    char *token;

    token = strtok(s, seps);
    while (token != NULL) {
        printf("토큰: %s\n", token);
        token = strtok(NULL, seps);
    }
    return 0;
}
