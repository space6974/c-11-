#include <stdio.h>
#include <string.h>

int main(void)
{
    const char key[] = "C";
    char buffer[80];

    do {
        printf("임베디드 장치에 가장 많이 사용되는 언어는? ");
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) return 1;
        buffer[strcspn(buffer, "\n")] = '\0';
    } while (strcmp(key, buffer) != 0);

    printf("맞았습니다!\n");
    return 0;
}
