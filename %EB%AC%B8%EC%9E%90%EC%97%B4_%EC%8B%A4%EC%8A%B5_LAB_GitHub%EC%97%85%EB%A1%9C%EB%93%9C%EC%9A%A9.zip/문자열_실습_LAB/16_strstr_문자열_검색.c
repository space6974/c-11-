#include <stdio.h>
#include <string.h>
#include <stddef.h>

int main(void)
{
    char s[] = "A bird in hand is worth two in the bush";
    char sub[] = "bird";
    char *p;

    p = strstr(s, sub);
    if (p == NULL) {
        printf("%s가 발견되지 않았음\n", sub);
    } else {
        printf("%s에서 첫 번째 %s가 %td에서 발견되었음\n", s, sub, p - s);
    }
    return 0;
}
