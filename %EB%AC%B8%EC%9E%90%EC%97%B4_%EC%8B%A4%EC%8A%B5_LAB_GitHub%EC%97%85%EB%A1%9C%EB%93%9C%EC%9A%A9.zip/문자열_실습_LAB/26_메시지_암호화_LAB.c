#include <stdio.h>
#include <string.h>

void encrypt(char cipher[], int shift);

int main(void)
{
    char cipher[200];
    int shift = 3;

    printf("문자열을 입력하시오: ");
    if (fgets(cipher, sizeof(cipher), stdin) == NULL) return 1;
    cipher[strcspn(cipher, "\n")] = '\0';

    encrypt(cipher, shift);
    return 0;
}

void encrypt(char cipher[], int shift)
{
    int i = 0;

    while (cipher[i] != '\0') {
        if (cipher[i] >= 'a' && cipher[i] <= 'z') {
            cipher[i] = (char)(cipher[i] + shift);
            if (cipher[i] > 'z') {
                cipher[i] = (char)(cipher[i] - 26);
            }
        }
        i++;
    }

    printf("암호화된 문자열: %s\n", cipher);
}
