#include <stdio.h>

int main(void)
{
    int ch;

    /* 입력 종료: Windows는 Ctrl+Z 후 Enter, Linux/macOS는 Ctrl+D */
    while ((ch = getchar()) != EOF) {
        putchar(ch);
    }

    return 0;
}
