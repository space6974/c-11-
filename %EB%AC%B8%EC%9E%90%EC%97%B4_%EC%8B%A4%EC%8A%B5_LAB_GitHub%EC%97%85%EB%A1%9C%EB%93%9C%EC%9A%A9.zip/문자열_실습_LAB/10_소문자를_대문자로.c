#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int c;

    while ((c = getchar()) != EOF) {
        if (islower((unsigned char)c)) {
            c = toupper((unsigned char)c);
        }
        putchar(c);
    }
    return 0;
}
