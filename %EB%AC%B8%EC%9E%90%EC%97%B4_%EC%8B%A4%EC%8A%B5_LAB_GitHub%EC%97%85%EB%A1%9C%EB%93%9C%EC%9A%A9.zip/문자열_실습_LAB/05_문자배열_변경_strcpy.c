#include <stdio.h>
#include <string.h>

int main(void)
{
    char str1[10] = "Hello";
    char str2[10] = "Hello";

    str1[0] = 'W';
    str1[1] = 'o';
    str1[2] = 'r';
    str1[3] = 'l';
    str1[4] = 'd';
    str1[5] = '\0';

    strcpy(str2, "World");

    printf("str1: %s\n", str1);
    printf("str2: %s\n", str2);
    return 0;
}
