#include <stdio.h>
#include <string.h>

static void remove_newline(char *s)
{
    s[strcspn(s, "\n")] = '\0';
}

int main(void)
{
    char name[100];
    char address[100];

    printf("이름을 입력하시오: ");
    if (fgets(name, sizeof(name), stdin) == NULL) return 1;
    remove_newline(name);

    printf("현재 거주하는 주소를 입력하시오: ");
    if (fgets(address, sizeof(address), stdin) == NULL) return 1;
    remove_newline(address);

    printf("안녕하세요, %s에 사는 %s 씨.\n", address, name);
    return 0;
}
