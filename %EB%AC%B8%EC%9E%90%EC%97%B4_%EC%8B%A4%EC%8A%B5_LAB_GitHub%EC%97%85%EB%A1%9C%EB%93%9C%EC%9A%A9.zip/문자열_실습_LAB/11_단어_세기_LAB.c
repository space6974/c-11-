#include <stdio.h>
#include <ctype.h>

int count_word(const char *s)
{
    int i;
    int wc = 0;
    int waiting = 1;

    for (i = 0; s[i] != '\0'; ++i) {
        if (isalpha((unsigned char)s[i])) {
            if (waiting) {
                wc++;
                waiting = 0;
            }
        } else {
            waiting = 1;
        }
    }
    return wc;
}

int main(void)
{
    int wc = count_word("the c book...");
    printf("단어의 개수: %d\n", wc);
    return 0;
}
