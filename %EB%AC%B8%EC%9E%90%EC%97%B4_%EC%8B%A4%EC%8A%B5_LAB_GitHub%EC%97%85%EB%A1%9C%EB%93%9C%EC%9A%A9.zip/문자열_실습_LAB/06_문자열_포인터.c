#include <stdio.h>

int main(void)
{
    const char *p = "HelloWorld";
    printf("%s\n", p);

    p = "Welcome to C World!";
    printf("%s\n", p);

    p = "Goodbye";
    printf("%s\n", p);

    return 0;
}
