#include <stdio.h>

int main(void)
{
    char instring[] = "file 12";
    char name[10];
    int number;

    if (sscanf(instring, "%9s %d", name, &number) != 2) {
        printf("문자열 변환에 실패했습니다.\n");
        return 1;
    }

    printf("name = %s\n", name);
    printf("number = %d\n", number);
    return 0;
}
