#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    int lower_case_count = 0;
    int upper_case_count = 0;
    int digit_count = 0;
    char pass[100];
    size_t len;
    size_t i;

    printf("패스워드를 입력하시오: ");
    if (fgets(pass, sizeof(pass), stdin) == NULL) return 1;
    pass[strcspn(pass, "\n")] = '\0';

    len = strlen(pass);
    if (len < 7) {
        printf("유효한 암호가 아닙니다.\n");
        return 0;
    }

    for (i = 0; i < len; i++) {
        unsigned char ch = (unsigned char)pass[i];
        if (islower(ch)) lower_case_count++;
        if (isupper(ch)) upper_case_count++;
        if (isdigit(ch)) digit_count++;
    }

    if (lower_case_count > 0 && upper_case_count > 0 && digit_count > 0) {
        printf("강한 암호입니다.\n");
    } else {
        printf("유효한 암호가 아닙니다.\n");
    }
    return 0;
}
