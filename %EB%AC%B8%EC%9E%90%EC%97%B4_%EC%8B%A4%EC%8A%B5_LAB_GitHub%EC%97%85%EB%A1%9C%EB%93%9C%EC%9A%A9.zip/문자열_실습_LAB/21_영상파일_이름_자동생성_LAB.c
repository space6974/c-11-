#include <stdio.h>

int main(void)
{
    char filename[100];
    int i;

    for (i = 0; i < 6; i++) {
        snprintf(filename, sizeof(filename), "image%d.jpg", i);
        printf("%s\n", filename);
    }
    return 0;
}
